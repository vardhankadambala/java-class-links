package com.ey.studentmarks.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ey.springboot.exception.ResourceNotFoundException;
import com.ey.studentmarks.model.Product;
import com.ey.studentmarks.repository.Prepository;

@CrossOrigin(origins = "http://localhost:3000")//--> to connect react
@RestController
@RequestMapping("/api/v1/")   //http://localhost:8085/api/v1/
public class Productcontroller {
	@Autowired
	private Prepository Prepository;
	
	@GetMapping("/product")
	public List<Product> getAllStudents(){
		return Prepository.findAll();
	}
	
	@PostMapping("/product")
	public Product createStudent(@RequestBody Product student) {
		return Prepository.save(student);
	}
	
	@GetMapping("/product/{id}")
	public ResponseEntity<Product> getStudentById(@PathVariable Long id) {
		Product student = Prepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
		return ResponseEntity.ok(student);
	}
	
	@PutMapping("/product/{id}")
	public ResponseEntity<Product> updateEmployeeById(@PathVariable Long id, @RequestBody Product studentdetails){
		Product student = Prepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
		student.setProductname(studentdetails.getProductname());
		student.setPquantity(studentdetails.getPquantity());
		student.setPrice(studentdetails.getPrice());
		
		Product updatedstudent=Prepository.save(student);
		return ResponseEntity.ok(updatedstudent);
	}
	
	@DeleteMapping("/product/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteEmployeeById(@PathVariable Long id){
		Product student = Prepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
		Prepository.delete(student);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
		
	}

}
