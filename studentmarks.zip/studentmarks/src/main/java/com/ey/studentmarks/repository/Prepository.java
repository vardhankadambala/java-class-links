package com.ey.studentmarks.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ey.studentmarks.model.Product;

@Repository
public interface Prepository extends JpaRepository<Product, Long>{

}
