package com.ey.studentmarks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductBackEnd {

	public static void main(String[] args) {
		SpringApplication.run(ProductBackEnd.class, args);
	}

}
