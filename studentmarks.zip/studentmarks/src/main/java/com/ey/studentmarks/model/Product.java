package com.ey.studentmarks.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "eyproducts")
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "p_name")
	private String productname;

	@Column(name = "p_quantity")
	private long pquantity ;
	
	@Column(name = "p_price")
	private String price;
	
	public Product() {
		
	}

	public Product(long productid, String productname, long pquantity, String price) {
		super();
		this.id = id;
		this.productname = productname;
		this.pquantity = pquantity;
		this.price = price;
	}

	public long getId() {
		return id;
	}

	public void setId(long productid) {
		this.id = id;
	}

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public long getPquantity() {
		return pquantity;
	}

	public void setPquantity(long pquantity) {
		this.pquantity = pquantity;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}


	
}
