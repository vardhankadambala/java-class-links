import axios from "axios";

const url ='http://localhost:8086/project/store/prouse'

export const CreateProUse = async(prouse)=>{
    const response = await axios.post(url,prouse);
    return response
}

export const getUserByUsername = async (userName) => {
    const response = await axios.get(url + '/' + userName);
    return response;
}

export const updateQty = async (id, userDetails) => {
    const response = await axios.put(url + '/' +id, userDetails);
    return response;
}

// useEffect(() => {

//     if(id){
//         getEmployeeById(id).then((response) =>{
//             setFirstName(response.data.firstName)
//             setLastName(response.data.lastName)
//             setEmail(response.data.emailId)
//             //console.log(response.data)
//         }).catch(error => {
//             console.log(error)
//         })
//     }

// }, [id])