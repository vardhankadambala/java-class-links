import React, {useState, useEffect} from 'react'
import { useNavigate } from 'react-router-dom'
import { getUserByUsername } from '../service/Prouse'
import { useParams } from 'react-router-dom'
import { updateQty } from '../service/Prouse'
const Cart = () => {
    const [users, setUsers] = useState([])

    const navigate = useNavigate()

    const {id} = useParams();

    useEffect(() => {
        getAllUsers();
    }, [])

    updateQty(id, ).then((response) => {
        navigate('/employees')
    }).catch(error => {
        console.log(error)
    })

    const getAllUsers = () => {
        getUserByUsername("sai123").then((response) => {
            setUsers(response.data)
            console.log(response.data);
        }).catch(error =>{
            console.log(error);
        })
    }
    return (
        <div className = "container">
            <br /><br />
            <h2 className = "text-center"> Items List</h2>
            <table className="table table-bordered table-striped">
                {/* <thead className="table-dark"> */}
                <thead>   
                    <tr>
                        <th> ITEM NAME </th>
                        <th> ITEM QUANTITY </th>
                        <th> ITEM PRICE </th>
                        <th> Action-1 </th>
                        <th> Action-2 </th>
                    </tr>
                </thead>
                <tbody>
                    {
                        users.map(
                            user =>
                            <tr key = {"sai123"}> 
                                <td> {user.proName} </td>
                                <td> {user.proQty} </td>
                                <td>{user.proPrice} </td>
                                <td>
                                    <button className = "btn btn-info" 
                                    style = {{marginLeft:"10px"}}> Update</button>
                                </td>
                                <td>
                                    <button className = "btn btn-danger" 
                                    style = {{marginLeft:"10px"}}> Delete</button>
                                </td>
                            </tr>
                        )
                    }
                </tbody>
            </table>
        </div>
    )
}

export default Cart