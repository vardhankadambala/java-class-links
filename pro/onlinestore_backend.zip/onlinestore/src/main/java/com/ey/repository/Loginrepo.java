//package com.ey.repository;
//
//import java.util.Optional;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
//import org.springframework.stereotype.Repository;
//
//import com.ey.model.User;
//
//@EnableJpaRepositories
//@Repository
//public interface Loginrepo extends JpaRepository<User, String>{
//	Optional<User> findOneByEmailAndPassword(String emailId, String userPass);
//}
