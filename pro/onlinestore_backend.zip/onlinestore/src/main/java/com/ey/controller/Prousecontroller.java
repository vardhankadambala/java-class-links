package com.ey.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ey.exception.ResourceNotFoundException;
import com.ey.model.Prouse;
import com.ey.repository.Prouserepo;


@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/project/store")  //http://localhost:8085/project/store/
public class Prousecontroller {
	@Autowired
	private Prouserepo prouserepo;
	
	@GetMapping("/prouse")
	public List<Prouse> getAllUsers(){
		return prouserepo.getProUsers();
	}
	
	@PostMapping("/prouse")
	public Prouse createEmployee(@RequestBody Prouse prouse) {
		int val=prouse.getProPrice()*prouse.getProQty();
		prouse.setProPrice(val);
		return prouserepo.save(prouse);
	}
	
	@GetMapping("/prouse/{userName}")
	public List<Prouse> getUserByUsername(@PathVariable String userName){
		List<Prouse> l=prouserepo.getProUserBYUserName(userName);
		return l;
	}
	
	
	@PutMapping("/prouse/{id}")
	public ResponseEntity<Prouse> updateUser(@PathVariable Long id, @RequestBody Prouse userDetails){
		Prouse user = prouserepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not exist with id :" + id));
		
		int a=user.getProPrice()/user.getProQty();
		System.out.println(a);
		user.setProQty(userDetails.getProQty());
		
		int val=a*user.getProQty();
		user.setProPrice(val);
		Prouse updateduser = prouserepo.save(user);

		return ResponseEntity.ok(updateduser);
	}
	
}
