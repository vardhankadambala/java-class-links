//package com.ey.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.ey.model.User;
//import com.ey.repository.Loginrepo;
//
//@CrossOrigin(origins = "http://localhost:3000")
//@RestController
//@RequestMapping("/project/store")  //http://localhost:8085/project/store/
//public class Logincontroll {
//	@Autowired
//	private Loginrepo loginrepo;
//	
//	@PostMapping("/log")
//	public boolean updateEmployee(@PathVariable String userName, @RequestBody User UserDetails){
//		
//		return false;
//		
//		
//	}
//}
